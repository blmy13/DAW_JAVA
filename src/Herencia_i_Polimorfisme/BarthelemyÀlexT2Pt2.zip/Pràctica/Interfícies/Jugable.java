package Herencia_i_Polimorfisme.Pràctica.Interfícies;

public interface Jugable {

    void juga();

    String mostraNom();

    String mostraInfo();


}
